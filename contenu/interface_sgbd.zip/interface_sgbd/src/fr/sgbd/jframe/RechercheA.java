package fr.sgbd.jframe;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.InputMethodEvent;
import java.awt.event.InputMethodListener;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;


import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSlider;
import javax.swing.JSplitPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.event.PopupMenuEvent;
import javax.swing.event.PopupMenuListener;
import javax.swing.table.DefaultTableModel;

import fr.sgbd.jdbc.Database;
import fr.sgbd.jdbc.Enregistrement;

public class RechercheA extends JPanel {

	Database d = new Database();
	ResultSet rs;
	JTable table_enr = new JTable();
	DefaultTableModel model = new DefaultTableModel();
	Object col[] = {"ENTITEFINANCIEREPROGRAMME","nomenclaturecomptable","depenses_recettes","investissement_fonctionnement","codechapitre","libellechapitre","codearticle", "libellearticle","codepresentationcroisee","libellepresentationcroisee","ordre_reel","montantrealise"};
	JComboBox<Integer> codeArticle;
	JTextField codeArticleLibelle;
	JComboBox<Integer> codeChapitre;
	JTextField codeChapitreLibelle;
	JComboBox<Integer> codePresentation;
	JTextField codePresentationLibelle;
	JComboBox<String> entite;
	JTextField nomanclature;
	JComboBox<String> i_f;
	JComboBox<String> o_r;
	JComboBox<String> d_r;
	boolean firstConnectionA = true;
	boolean firstConnectionB = true;
	boolean firstConnectionP = true;
	boolean firstConnectionE = true;
	boolean firstConnectionA1 = true;
	boolean firstConnectionB1 = true;
	boolean firstConnectionP1 = true;
	boolean firstConnectionE1 = true;
	Map<String,String> listeFiltre = new HashMap<>();

	public RechercheA() {
		this.setSize(1600,660);
		this.setLayout(new BorderLayout());

		JPanel container_filtre = new JPanel();
		container_filtre.setLayout(new GridLayout(10,1,50,20));

		JPanel panel_article = new JPanel();
		panel_article.setLayout(new GridLayout(4,1));
		JLabel article_label = new JLabel("CODE ARTICLE", SwingConstants.CENTER);
		codeArticle = new JComboBox<>();
		JLabel article_label_l = new JLabel("LIBELLE ARTICLE", SwingConstants.CENTER);
		codeArticleLibelle = new JTextField();
		codeArticleLibelle.setEditable(false);
		panel_article.add(article_label);
		panel_article.add(codeArticle);
		panel_article.add(article_label_l);
		panel_article.add(codeArticleLibelle);


		JPanel panel_chapitre = new JPanel();
		panel_chapitre.setLayout(new GridLayout(4,1));
		JLabel chapitre_label = new JLabel("CODE CHAPITRE", SwingConstants.CENTER);
		codeChapitre = new JComboBox<>();
		JLabel chapitre_label_l = new JLabel("LIBELLE CHAPITRE", SwingConstants.CENTER);
		codeChapitreLibelle = new JTextField();
		codeChapitreLibelle.setEditable(false);
		panel_chapitre.add(chapitre_label);
		panel_chapitre.add(codeChapitre);
		panel_chapitre.add(chapitre_label_l);
		panel_chapitre.add(codeChapitreLibelle);

		JPanel panel_presentation = new JPanel();
		panel_presentation.setLayout(new GridLayout(4,1));
		JLabel presentation_label = new JLabel("CODE PRESENTATION", SwingConstants.CENTER);
		codePresentation = new JComboBox<>();
		JLabel presentation_label_l = new JLabel("LIBELLE PRESENTATION", SwingConstants.CENTER);
		codePresentationLibelle = new JTextField();
		codePresentationLibelle.setEditable(false);
		panel_presentation.add(presentation_label);
		panel_presentation.add(codePresentation);
		panel_presentation.add(presentation_label_l);
		panel_presentation.add(codePresentationLibelle);


		JPanel panel_entite = new JPanel();
		panel_entite.setLayout(new GridLayout(4,1));
		JLabel entite_label = new JLabel("ENTITE", SwingConstants.CENTER);
		entite = new JComboBox<>();
		JLabel entite_label_l = new JLabel("NOMANCLATURE", SwingConstants.CENTER);
		nomanclature = new JTextField();
		nomanclature.setEditable(false);
		panel_entite.add(entite_label);
		panel_entite.add(entite);
		panel_entite.add(entite_label_l);
		panel_entite.add(nomanclature);

		JPanel d_r_panel = new JPanel();
		d_r_panel.setLayout(new GridLayout(3,1));
		JLabel d_r_label = new JLabel("DEPENSE_RECETTE", SwingConstants.CENTER);
		String[] d_rItem = {"","Depense","Recette"};
		d_r = new JComboBox<>(d_rItem);
		d_r_panel.add(d_r_label);
		d_r_panel.add(d_r);

		JPanel i_f_panel = new JPanel();
		i_f_panel.setLayout(new GridLayout(3,1));
		JLabel i_f_label = new JLabel("INVESTISSEMENT_FONCTIONNEMENT", SwingConstants.CENTER);
		String[] i_fItem = {"","Investisssement","Fonctionnement"};
		i_f = new JComboBox<>(i_fItem);
		i_f_panel.add(i_f_label);
		i_f_panel.add(i_f);

		JPanel o_r_panel = new JPanel();
		o_r_panel.setLayout(new GridLayout(3,1));
		JLabel o_r_label = new JLabel("ORDES_REEL", SwingConstants.CENTER);
		String[] o_rItem = {"","Odre","Reel"};
		o_r = new JComboBox<>(o_rItem);
		o_r_panel.add(o_r_label);
		o_r_panel.add(o_r);

		//PANEL SLIDER
		JPanel slide_container = new JPanel();
		JSlider slider_montant = new JSlider(0,15000, 0);
		slider_montant.setPaintTrack(true); 
		slider_montant.setPaintTicks(true); 
		slider_montant.setPaintLabels(true); 
		slider_montant.setMajorTickSpacing(15000/3); 
		slider_montant.setMinorTickSpacing(500); 

		//Panel Min MAX
		JPanel panel_minMax = new JPanel();
		panel_minMax.setLayout(null);
		panel_minMax.setSize(150,300);

		JLabel min_label = new JLabel("MIN : ");
		min_label.setBounds(0,5 , 50, 20);
		JTextField montant_min = new JTextField();


		JLabel max_label = new JLabel("MAX : ");
		max_label.setBounds(0,25 , 50, 20);
		JTextField montant_max = new JTextField();

		montant_min.setBounds(50,5, 100, 20);
		montant_max.setBounds(50,25 , 100, 20);



		panel_minMax.add(max_label);
		panel_minMax.add(montant_max);
		panel_minMax.add(min_label);
		panel_minMax.add(montant_min);

		JLabel montant = new JLabel();

		slide_container.add(slider_montant);
		slide_container.add(montant);
		montant.setText("" + slider_montant.getValue());
		slider_montant.addChangeListener(new ChangeListener() {

			@Override
			public void stateChanged(ChangeEvent arg0) {
				montant.setText("" + slider_montant.getValue());
				montant_max.setText("" + slider_montant.getValue());
				listeFiltre.put("min", String.valueOf(0));
				listeFiltre.put("max", String.valueOf(slider_montant.getValue()));
			}
		});
	

		JPanel btn_filter_panel = new JPanel();
		btn_filter_panel.setLayout(new FlowLayout());
		JButton btn_filter = new JButton("FILTRER");
		JButton btn_reset = new JButton("RESET");
		btn_filter_panel.add(btn_filter);
		btn_filter_panel.add(btn_reset);


		container_filtre.add(panel_article);
		container_filtre.add(panel_chapitre);
		container_filtre.add(panel_presentation);
		container_filtre.add(panel_entite);
		container_filtre.add(d_r_panel);
		container_filtre.add(i_f_panel);
		container_filtre.add(o_r_panel);
		container_filtre.add(slide_container);
		container_filtre.add(panel_minMax);
		container_filtre.add(btn_filter_panel);

		JScrollPane filtre_scroll = new JScrollPane(container_filtre);
		//filtre_scroll.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
		//filtre_scroll.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);



		model.setColumnIdentifiers(col);
		table_enr.setModel(model);
		JScrollPane tableau = new JScrollPane(table_enr);

		JSplitPane slit_container = new JSplitPane(SwingConstants.VERTICAL,filtre_scroll,tableau);
		slit_container.setSize(350,660);
		slit_container.setOrientation(SwingConstants.VERTICAL); 
		this.add(slit_container);

		/***************CODE JCOMBOBOX ******************/
		//a
		codeArticle.addPopupMenuListener(new PopupMenuListener() {	
			@Override
			public void popupMenuWillBecomeVisible(PopupMenuEvent arg0) {
				if(firstConnectionA) {
					getListArticle();
					firstConnectionA =false;
				}

			}

			@Override
			public void popupMenuCanceled(PopupMenuEvent arg0) {
				// TODO Auto-generated method stub

			}

			@Override
			public void popupMenuWillBecomeInvisible(PopupMenuEvent arg0) {
				// TODO Auto-generated method stub

			}

		});
		codeArticle.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				int n=0;
				n = (int)(codeArticle.getSelectedItem());
				codeArticleLibelle.setText(getLibelleArticle(n));
				listeFiltre.put("codearticle",String.valueOf(codeArticle.getSelectedItem()));
				
				if(!montant_max.getText().isEmpty()) {
					listeFiltre.put("max", String.valueOf(montant_max.getText()));
				}
				if(!montant_min.getText().isEmpty()) {
					listeFiltre.put("min", String.valueOf(montant_min.getText()));
				}
				System.out.println(listeFiltre);
				show_enregistrement();

			}
		});
		//b
		codeChapitre.addPopupMenuListener(new PopupMenuListener() {	
			@Override
			public void popupMenuWillBecomeVisible(PopupMenuEvent arg0) {
				if(firstConnectionB) {
					getListChapitre();
					firstConnectionB =false;
				}

			}

			@Override
			public void popupMenuCanceled(PopupMenuEvent arg0) {
				// TODO Auto-generated method stub

			}

			@Override
			public void popupMenuWillBecomeInvisible(PopupMenuEvent arg0) {
				// TODO Auto-generated method stub

			}

		});
		codeChapitre.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				int n=0;
				n = (int)(codeChapitre.getSelectedItem());
				codeChapitreLibelle.setText(getLibelleChapitre(n));
				listeFiltre.put("codechapitre",String.valueOf(codeChapitre.getSelectedItem()));
				
				if(!montant_max.getText().isEmpty()) {
					listeFiltre.put("max", String.valueOf(montant_max.getText()));
				}
				if(!montant_min.getText().isEmpty()) {
					listeFiltre.put("min", String.valueOf(montant_min.getText()));
				}
				System.out.println(listeFiltre);
				show_enregistrement();

			}
		});
		//p
		codePresentation.addPopupMenuListener(new PopupMenuListener() {	
			@Override
			public void popupMenuWillBecomeVisible(PopupMenuEvent arg0) {
				if(firstConnectionP) {
					getListPresentation();
					firstConnectionP =false;
				}

			}

			@Override
			public void popupMenuCanceled(PopupMenuEvent arg0) {
				// TODO Auto-generated method stub

			}

			@Override
			public void popupMenuWillBecomeInvisible(PopupMenuEvent arg0) {
				// TODO Auto-generated method stub

			}

		});
		codePresentation.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				int n=0;
				n = (int)(codePresentation.getSelectedItem());
				codePresentationLibelle.setText(getLibellePresentation(n));
				listeFiltre.put("codepresentationcroisee",String.valueOf(codePresentation.getSelectedItem()));
				
				if(!montant_max.getText().isEmpty()) {
					listeFiltre.put("max", String.valueOf(montant_max.getText()));
				}
				if(!montant_min.getText().isEmpty()) {
					listeFiltre.put("min", String.valueOf(montant_min.getText()));
				}
				System.out.println(listeFiltre);
				show_enregistrement();

			}
		});
		//e
		entite.addPopupMenuListener(new PopupMenuListener() {	
			@Override
			public void popupMenuWillBecomeVisible(PopupMenuEvent arg0) {
				if(firstConnectionE) {
					getListEntite();
					firstConnectionE =false;
				}

			}

			@Override
			public void popupMenuCanceled(PopupMenuEvent arg0) {
				// TODO Auto-generated method stub

			}

			@Override
			public void popupMenuWillBecomeInvisible(PopupMenuEvent arg0) {
				// TODO Auto-generated method stub

			}

		});
		entite.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				String n="";
				n = (String)(entite.getSelectedItem());
				nomanclature.setText(getLibelleEntite(n));
				listeFiltre.put("entitefinanciereprogramme",String.valueOf(entite.getSelectedItem()));
				
				if(!montant_max.getText().isEmpty()) {
					listeFiltre.put("max", String.valueOf(montant_max.getText()));
				}
				if(!montant_min.getText().isEmpty()) {
					listeFiltre.put("min", String.valueOf(montant_min.getText()));
				}
				System.out.println(listeFiltre);
				show_enregistrement();

			}
		});

		d_r.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				listeFiltre.put("depenses_recettes",String.valueOf(d_r.getSelectedItem()));
				
				if(!montant_max.getText().isEmpty()) {
					listeFiltre.put("max", String.valueOf(montant_max.getText()));
				}
				if(!montant_min.getText().isEmpty()) {
					listeFiltre.put("min", String.valueOf(montant_min.getText()));
				}
				System.out.println(listeFiltre);
				show_enregistrement();

			}
		});

		o_r.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				listeFiltre.put("ordre_reel",String.valueOf(o_r.getSelectedItem()));
				
				if(!montant_max.getText().isEmpty()) {
					listeFiltre.put("max", String.valueOf(montant_max.getText()));
				}
				if(!montant_min.getText().isEmpty()) {
					listeFiltre.put("min", String.valueOf(montant_min.getText()));
				}
				System.out.println(listeFiltre);
				show_enregistrement();

			}
		});

		i_f.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				listeFiltre.put("investissement_fonctionnement",String.valueOf(i_f.getSelectedItem()));
				
				if(!montant_max.getText().isEmpty()) {
					listeFiltre.put("max", String.valueOf(montant_max.getText()));
				}
				if(!montant_min.getText().isEmpty()) {
					listeFiltre.put("min", String.valueOf(montant_min.getText()));
				}
				System.out.println(listeFiltre);
				show_enregistrement();

			}
		});




		btn_filter.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				if(!montant_max.getText().isEmpty()) {
					listeFiltre.put("max", String.valueOf(montant_max.getText()));
				}
				if(!montant_min.getText().isEmpty()) {
					listeFiltre.put("min", String.valueOf(montant_min.getText()));
				}
				System.out.println(listeFiltre);
				show_enregistrement();
			}
		});
		btn_reset.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				listeFiltre.clear();
				codeArticle.addItem(0);
				codeArticleLibelle.setText("");
				codeChapitre.addItem(0);
				codeChapitreLibelle.setText("");
				codePresentation.addItem(0);
				codePresentationLibelle.setText("");
				entite.addItem("");
				nomanclature.setText("");
				o_r.addItem("");
				i_f.addItem("");
				d_r.addItem("");

				codeArticle.setSelectedIndex(0);
				codeArticleLibelle.setText("");
				codeChapitre.setSelectedIndex(0);
				codeChapitreLibelle.setText("");
				codePresentation.setSelectedIndex(0);
				codePresentationLibelle.setText("");
				entite.setSelectedIndex(0);
				nomanclature.setText("");
				o_r.setSelectedIndex(0);
				i_f.setSelectedIndex(0);
				d_r.setSelectedIndex(0);
				montant_max.setText("");
				montant_min.setText("");

			}
		});
	}

	//Recuperer les valeurs des enregistrements
	public ArrayList<Enregistrement> enrListe(){
		ArrayList<Enregistrement> enrListe = new ArrayList<>();
		enrListe.clear();
		rs = d.filterSearch(listeFiltre);

		try {
			Enregistrement enregistrement;
			while(rs.next()) {	
				enregistrement = new Enregistrement(rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5), rs.getInt(6), rs.getString(7), rs.getInt(8), rs.getString(9), rs.getInt(10), rs.getString(11), rs.getString(12), rs.getFloat(13));
				enrListe.add(enregistrement);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return enrListe;
	}

	//Remplir le tableau 
	public void show_enregistrement() {
		model.setRowCount(0); 
		ArrayList<Enregistrement> list = enrListe();
		Object[] row = new Object[13];
		for(int i=0;i<list.size();i++) {
			row[0]=list.get(i).getENTITEFINANCIEREPROGRAMME();
			row[1]=list.get(i).getNomenclaturecomptable();
			row[2]=list.get(i).getDepenses_recettes();
			row[3]=list.get(i).getInvestissement_fonctionnement();
			row[4]=list.get(i).getCodechapitre();
			row[5]=list.get(i).getLibellechapitre();
			row[6]=list.get(i).getCodearticle();
			row[7]=list.get(i).getLibellearticle();
			row[8]=list.get(i).getCodepresentationcroisee();
			row[9]=list.get(i).getLibellepresentationcroisee();
			row[10]=list.get(i).getOrdre_reel();
			row[11]=list.get(i).getMontantrealise();
			model.addRow(row);
		}
	}

	public void getListArticle(){
		ResultSet rs = d.querySelectAllOrderBy("article", "codearticle");
		codeArticle.removeAllItems();
		codeArticle.addItem(0);
		try {
			rs.setFetchSize(600);
			while(rs.next()) {	
				codeArticle.addItem(rs.getInt(1));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	//Recuperer le labelle du code article en fonction de son code
	public String getLibelleArticle(int num) {
		String result = "";
		if (num == 0) {
			return "";
		}else {
			ResultSet rs = d.querySelectWhereColonneInt("article","codearticle", num);
			try {	
				while (rs.next()) {
					result = rs.getString(2);

				}

			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return result;

		}
	}

	public void getListChapitre(){
		ResultSet rs = d.querySelectAllOrderBy("chapitre", "codechapitre");
		codeChapitre.removeAllItems();
		codeChapitre.addItem(0);
		try {
			rs.setFetchSize(600);
			while(rs.next()) {	
				codeChapitre.addItem(rs.getInt(1));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	//Recuperer le labelle du code chapitre en fonction de son code
	public String getLibelleChapitre(int num) {
		String result = "";
		if (num == 0) {
			return "";
		}else {

			ResultSet rs = d.querySelectWhereColonneInt("chapitre","codechapitre", num);
			try {	
				while (rs.next()) {
					result = rs.getString(2);
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return result;
		}

	}

	public void getListPresentation(){
		ResultSet rs = d.querySelectAllOrderBy("presentationcroisee", "CODEPRESENTATIONCROISEE");
		codePresentation.removeAllItems();
		codePresentation.addItem(0);
		try {
			rs.setFetchSize(600);
			while(rs.next()) {	
				codePresentation.addItem(rs.getInt(1));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public String getLibellePresentation(int num) {
		String result = "";

		ResultSet rs = d.querySelectWhereColonneInt("presentationcroisee","CODEPRESENTATIONCROISEE", num);
		try {	
			while (rs.next()) {
				result = rs.getString(2);

			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return result;


	}

	public void getListEntite(){
		ResultSet rs = d.querySelectAllOrderBy("ENTITEFINANCIEREPROGRAMME", "ENTITEFINANCIEREPROGRAMME");
		entite.removeAllItems();
		entite.addItem("");
		try {
			rs.setFetchSize(600);
			while(rs.next()) {	
				entite.addItem(rs.getString(1));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	//Recuperer le labelle du code article en fonction de son code
	public String getLibelleEntite(String code) {
		String result = "";

		ResultSet rs = d.querySelectWhereColonneString("ENTITEFINANCIEREPROGRAMME","ENTITEFINANCIEREPROGRAMME", code);
		try {	
			while (rs.next()) {
				result = rs.getString(2);

			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return result;


	}
}
