package fr.jgbd.main;


import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.BorderFactory;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JLayeredPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.border.Border;

import fr.sgbd.jframe.CRUD;
import fr.sgbd.jframe.RechercheA;
import fr.sgbd.jframe.RechercheC;


public class MainJFrame extends JFrame{

	static MainJFrame homeJ = new MainJFrame();

	public static void main(String[] args) {
		java.awt.EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
            	 homeJ.setVisible(true);   

            }
        });

	}
	
	public MainJFrame() {
		super("GESTION COMPTE ADMINISTRATIF");
		this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		//r�cuperer la dimension de l'�cran
		Dimension tailleMoniteur = Toolkit.getDefaultToolkit().getScreenSize();
		int longueur = tailleMoniteur.width * 83/100;
		int hauteur = tailleMoniteur.height * 83/100;
		this.setSize(longueur, hauteur);
		//this.setSize(1600, 750);
		//this.setMinimumSize(new Dimension(longueur, hauteur));
		this.setLocationRelativeTo(null);
		//this.setResizable(false);
		
		RechercheC RechercheC = new RechercheC();
		RechercheA RechercheA = new RechercheA();
		CRUD CRUD = new CRUD();
		/*---------------------CONTAINER-------------------------*/
		//Container
		JPanel container = (JPanel) this.getContentPane();
		container.setLayout(new BorderLayout());
		//container.setBackground(Color.red);

		
		/*--------------------TOP CONTAINER--------------------------*/
		JPanel topContainer = new JPanel();
		topContainer.setLayout(new BorderLayout());
		
		
		/*--------------------TITLE CONTAINER--------------------------*/
		JPanel titre_container = new JPanel();
		titre_container.setPreferredSize(new Dimension(1600,80));
		//titre_container.setBackground(Color.blue);
		JLabel titre_label = new JLabel("<html><div style='align-text:center;'>GESTION COMPTE ADMINISTRATIF</div></html>");
		titre_label.setForeground(new Color(0x09105A));
		titre_label.setFont(new Font("Serif", Font.BOLD,22));
		
		titre_container.add(titre_label);
		
		/*--------------------NAVBAR--------------------------*/
		//Navbar
		JPanel nav_container = new JPanel();
		nav_container.setPreferredSize(new Dimension(1600,80));
		//nav_container.setBackground(Color.gray);
		nav_container.setBackground(new Color(0xC8C8C8));
		nav_container.setLayout(new FlowLayout(3,30,30));

		/*--------------------MENU ONGLET--------------------------*/
		//Recherche par code
		JLabel recherche_code = new JLabel("RECHERCHE PAR CODE");
		recherche_code.setForeground(new Color(0x161E86));
		recherche_code.setFont(new Font("Serif", Font.BOLD,17));
	
		
		//Recherche avancee
		JLabel recherche_avancee = new JLabel("RECHERCHE AVANCEE");
		recherche_avancee.setForeground(new Color(0x333980));
		recherche_avancee.setFont(new Font("Serif", Font.BOLD,17));
		
		//Submenu Enregistrement
		JLabel submenu = new JLabel("ENREGISTREMENT");
		submenu.setForeground(new Color(0x333980));
		submenu.setFont(new Font("Serif", Font.BOLD,17));
		
		nav_container.add(recherche_code);
		nav_container.add(recherche_avancee);
		nav_container.add(submenu);
		
		Border border = BorderFactory.createMatteBorder(0, 0, 3, 0,new Color(0x161E86));
		Border borderEmpty = BorderFactory.createEmptyBorder();
		recherche_code.setBorder(border);
		
		
		topContainer.add(titre_container,BorderLayout.NORTH);
		topContainer.add(nav_container, BorderLayout.SOUTH);
		
		
		/*--------------------ACTION MENU--------------------------*/
		recherche_code.addMouseListener(new MouseAdapter() {	
			@Override
			public void  mouseClicked(MouseEvent e)  {
				CRUD.setVisible(false);
				RechercheA.setVisible(false);
				RechercheC.setVisible(true);
				recherche_avancee.setBorder(borderEmpty);
				submenu.setBorder(borderEmpty);
				recherche_avancee.setForeground(new Color(0x333980));
				submenu.setForeground(new Color(0x333980));
				recherche_code.setForeground(new Color(0x161E86));
				recherche_code.setBorder(border);
			}
		});
		
		recherche_avancee.addMouseListener(new MouseAdapter() {	
			@Override
			public void  mouseClicked(MouseEvent e)  {
				CRUD.setVisible(false);
				RechercheA.setVisible(true);
				RechercheC.setVisible(false);
				recherche_code.setBorder(borderEmpty);
				submenu.setBorder(borderEmpty);
				recherche_avancee.setForeground(new Color(0x161E86));
				submenu.setForeground(new Color(0x333980));
				recherche_code.setForeground(new Color(0x333980)); 
				recherche_avancee.setBorder(border);
				/*Font font = recherche_avancee.getFont(); 
				Map attributes = font.getAttributes(); 
				attributes.put(TextAttribute.UNDERLINE, TextAttribute.UNDERLINE_ON); 
				recherche_avancee.setFont(font.deriveFont(attributes)); */
			}
			
			
		});
		
		
		submenu.addMouseListener(new MouseAdapter() {	
			@Override
			public void  mouseClicked(MouseEvent e)  {
				CRUD.setVisible(true);
				RechercheA.setVisible(false);
				RechercheC.setVisible(false);
				recherche_code.setBorder(borderEmpty);
				recherche_avancee.setBorder(borderEmpty);
				recherche_avancee.setForeground(new Color(0x333980));
				submenu.setForeground(new Color(0x161E86));
				recherche_code.setForeground(new Color(0x333980));
				submenu.setBorder(border);
				
			}
		});
		
		
		/*layer*/
		JLayeredPane content = new JLayeredPane();
		content.setPreferredSize(new Dimension(1500,660));
		content.setBackground(new Color(0xC8C8C8));
		JScrollPane pane_container = new JScrollPane(content);
		pane_container.setPreferredSize(new Dimension(1500,670));
		content.setLayout(null);
		content.add(RechercheC);
		content.add(RechercheA);
		content.add(CRUD);
		CRUD.setVisible(false);
		RechercheA.setVisible(false);
		RechercheC.setVisible(true);
		
		/*-------------------ADD COMPONENT IN CONTAINER---------------------------*/
		//add coponent in container
		container.add(topContainer, BorderLayout.NORTH);
		container.add(pane_container, BorderLayout.CENTER);
		pack();
	}
	
	
	

}
